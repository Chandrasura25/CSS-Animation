export default interface CalendarRenderEndEventObject {
    /**
     * The rendered year.
     */
    currentYear: number;
}