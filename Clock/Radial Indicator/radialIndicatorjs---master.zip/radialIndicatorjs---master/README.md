# radialIndicator
A simple and light weight circular indicator plugin.

Check demo and documentation on <a href="http://ignitersworld.com/lab/radialIndicator.html">http://ignitersworld.com/lab/radialIndicator.html</a>

<h3>Major updates</h3>

<strong>1.2.0</strong>
- Added option to allow user interaction on mouse and touch events.
- Added precision option to support float value.

<strong>1.1.0</strong>
- Fixed draw issue on ipad and android devices and added onAnimationComplete callback.