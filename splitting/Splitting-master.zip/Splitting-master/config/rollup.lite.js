export default {
  input: 'src/lite.js', 
  output: [
    { file: 'dist/splitting-lite.js', name: 'Splitting', format: 'umd' }
  ]
}